package com.signify.OnlineSystemApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
