package com.signify.OnlineSystemApplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineSystemApplication.class, args);
	}

}
